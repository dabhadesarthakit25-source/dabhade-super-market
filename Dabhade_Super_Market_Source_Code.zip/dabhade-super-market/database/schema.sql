CREATE DATABASE IF NOT EXISTS dabhade_super_market
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dabhade_super_market;
-- Spring Boot JPA creates products, sales, sale_items and held_bills tables.
-- This file intentionally creates only the database; let Hibernate create/update tables.
