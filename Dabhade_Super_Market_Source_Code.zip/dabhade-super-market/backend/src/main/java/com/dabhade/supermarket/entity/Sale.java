package com.dabhade.supermarket.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="sales")
public class Sale {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private LocalDateTime createdAt = LocalDateTime.now();
    @Column(precision=12, scale=2) private BigDecimal subtotal;
    @Column(precision=12, scale=2) private BigDecimal discount;
    @Column(precision=12, scale=2) private BigDecimal cgst;
    @Column(precision=12, scale=2) private BigDecimal sgst;
    @Column(precision=12, scale=2) private BigDecimal total;
    private String paymentMethod;
    private String customerName;
    @OneToMany(mappedBy="sale", cascade=CascadeType.ALL, orphanRemoval=true, fetch=FetchType.EAGER)
    private List<SaleItem> items = new ArrayList<>();

    public Long getId(){return id;} public LocalDateTime getCreatedAt(){return createdAt;}
    public BigDecimal getSubtotal(){return subtotal;} public void setSubtotal(BigDecimal v){subtotal=v;}
    public BigDecimal getDiscount(){return discount;} public void setDiscount(BigDecimal v){discount=v;}
    public BigDecimal getCgst(){return cgst;} public void setCgst(BigDecimal v){cgst=v;}
    public BigDecimal getSgst(){return sgst;} public void setSgst(BigDecimal v){sgst=v;}
    public BigDecimal getTotal(){return total;} public void setTotal(BigDecimal v){total=v;}
    public String getPaymentMethod(){return paymentMethod;} public void setPaymentMethod(String v){paymentMethod=v;}
    public String getCustomerName(){return customerName;} public void setCustomerName(String v){customerName=v;}
    public List<SaleItem> getItems(){return items;}
    public void addItem(SaleItem item){items.add(item); item.setSale(this);}
}
