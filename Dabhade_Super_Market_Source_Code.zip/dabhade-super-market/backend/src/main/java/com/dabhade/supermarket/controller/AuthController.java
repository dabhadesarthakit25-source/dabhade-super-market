package com.dabhade.supermarket.controller;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.Map;
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @GetMapping("/me") public Map<String,String> me(Principal principal) {
        return Map.of("username", principal.getName(), "status", "authenticated");
    }
}
