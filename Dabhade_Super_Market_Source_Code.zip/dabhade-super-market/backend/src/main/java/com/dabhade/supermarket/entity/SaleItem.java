package com.dabhade.supermarket.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;

@Entity
@Table(name="sale_items")
public class SaleItem {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    private Long productId;
    private String productName;
    private String barcode;
    private Integer quantity;
    @Column(precision=12, scale=2) private BigDecimal unitPrice;
    @Column(precision=12, scale=2) private BigDecimal gstRate;
    @Column(precision=12, scale=2) private BigDecimal lineTotal;
    @JsonIgnore @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="sale_id") private Sale sale;

    public Long getId(){return id;}
    public Long getProductId(){return productId;} public void setProductId(Long v){productId=v;}
    public String getProductName(){return productName;} public void setProductName(String v){productName=v;}
    public String getBarcode(){return barcode;} public void setBarcode(String v){barcode=v;}
    public Integer getQuantity(){return quantity;} public void setQuantity(Integer v){quantity=v;}
    public BigDecimal getUnitPrice(){return unitPrice;} public void setUnitPrice(BigDecimal v){unitPrice=v;}
    public BigDecimal getGstRate(){return gstRate;} public void setGstRate(BigDecimal v){gstRate=v;}
    public BigDecimal getLineTotal(){return lineTotal;} public void setLineTotal(BigDecimal v){lineTotal=v;}
    public Sale getSale(){return sale;} public void setSale(Sale v){sale=v;}
}
