package com.dabhade.supermarket.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="products", uniqueConstraints=@UniqueConstraint(columnNames="barcode"))
public class Product {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false) private String name;
    @Column(nullable=false, unique=true) private String barcode;
    @Column(nullable=false, precision=12, scale=2) private BigDecimal price;
    @Column(nullable=false, precision=5, scale=2) private BigDecimal gstRate = BigDecimal.ZERO;
    @Column(nullable=false) private Integer stock = 0;
    private String unit = "pcs";
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId(){return id;} public void setId(Long v){id=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getBarcode(){return barcode;} public void setBarcode(String v){barcode=v;}
    public BigDecimal getPrice(){return price;} public void setPrice(BigDecimal v){price=v;}
    public BigDecimal getGstRate(){return gstRate;} public void setGstRate(BigDecimal v){gstRate=v;}
    public Integer getStock(){return stock;} public void setStock(Integer v){stock=v;}
    public String getUnit(){return unit;} public void setUnit(String v){unit=v;}
    public LocalDateTime getCreatedAt(){return createdAt;}
}
