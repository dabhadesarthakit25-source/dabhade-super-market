package com.dabhade.supermarket.controller;

import com.dabhade.supermarket.entity.HeldBill;
import com.dabhade.supermarket.repository.HeldBillRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/held-bills")
public class HeldBillController {
    private final HeldBillRepository repo;
    public HeldBillController(HeldBillRepository repo){this.repo=repo;}
    @GetMapping public List<HeldBill> all(){return repo.findAll();}
    @PostMapping public HeldBill hold(@RequestBody HeldBill bill){
        if(bill.getPayload()==null || bill.getPayload().isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Empty held bill");
        bill.setId(null); return repo.save(bill);
    }
    @GetMapping("/{id}") public HeldBill one(@PathVariable Long id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));}
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){repo.deleteById(id);}
}
