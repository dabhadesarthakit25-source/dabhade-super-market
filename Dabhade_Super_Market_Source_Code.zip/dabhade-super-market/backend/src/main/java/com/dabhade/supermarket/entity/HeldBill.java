package com.dabhade.supermarket.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="held_bills")
public class HeldBill {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Lob @Column(nullable=false) private String payload;
    private LocalDateTime createdAt = LocalDateTime.now();
    public Long getId(){return id;} public String getPayload(){return payload;}
    public void setPayload(String v){payload=v;} public LocalDateTime getCreatedAt(){return createdAt;}
}
