package com.dabhade.supermarket.controller;

import com.dabhade.supermarket.dto.CreateSaleRequest;
import com.dabhade.supermarket.entity.*;
import com.dabhade.supermarket.repository.*;
import jakarta.transaction.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.math.*;
import java.util.List;

@RestController
@RequestMapping("/api/sales")
public class SaleController {
    private final SaleRepository sales; private final ProductRepository products;
    public SaleController(SaleRepository sales,ProductRepository products){this.sales=sales;this.products=products;}

    @PostMapping @Transactional
    public Sale create(@RequestBody CreateSaleRequest req){
        if(req.items()==null || req.items().isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Bill has no items");
        Sale sale=new Sale();
        sale.setCustomerName(req.customerName()==null?"":req.customerName());
        sale.setPaymentMethod(req.paymentMethod());
        BigDecimal subtotal=BigDecimal.ZERO, cgst=BigDecimal.ZERO, sgst=BigDecimal.ZERO;
        for(var line:req.items()){
            Product p=products.findById(line.productId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Product not found"));
            if(line.quantity()==null || line.quantity()<1 || p.getStock()<line.quantity())
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Insufficient stock for "+p.getName());
            BigDecimal base=p.getPrice().multiply(BigDecimal.valueOf(line.quantity()));
            BigDecimal tax=base.multiply(p.getGstRate()==null?BigDecimal.ZERO:p.getGstRate()).divide(new BigDecimal("100"),2,RoundingMode.HALF_UP);
            BigDecimal half=tax.divide(new BigDecimal("2"),2,RoundingMode.HALF_UP);
            SaleItem item=new SaleItem();
            item.setProductId(p.getId()); item.setProductName(p.getName()); item.setBarcode(p.getBarcode());
            item.setQuantity(line.quantity()); item.setUnitPrice(p.getPrice()); item.setGstRate(p.getGstRate());
            item.setLineTotal(base.add(tax)); sale.addItem(item);
            subtotal=subtotal.add(base); cgst=cgst.add(half); sgst=sgst.add(tax.subtract(half));
            p.setStock(p.getStock()-line.quantity()); products.save(p);
        }
        BigDecimal discount=req.discount()==null?BigDecimal.ZERO:req.discount();
        if(discount.compareTo(subtotal.add(cgst).add(sgst))>0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Discount exceeds bill total");
        sale.setSubtotal(subtotal); sale.setDiscount(discount); sale.setCgst(cgst); sale.setSgst(sgst);
        sale.setTotal(subtotal.add(cgst).add(sgst).subtract(discount));
        return sales.save(sale);
    }
    @GetMapping public List<Sale> all(){return sales.findAll(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC,"createdAt"));}
    @GetMapping("/{id}") public Sale one(@PathVariable Long id){return sales.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));}
}
