package com.dabhade.supermarket.dto;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;

public record CreateSaleRequest(
    String customerName,
    @NotBlank String paymentMethod,
    @NotNull @DecimalMin("0.0") BigDecimal discount,
    @NotEmpty List<Line> items
) {
    public record Line(@NotNull Long productId, @NotNull @Min(1) Integer quantity) {}
}
