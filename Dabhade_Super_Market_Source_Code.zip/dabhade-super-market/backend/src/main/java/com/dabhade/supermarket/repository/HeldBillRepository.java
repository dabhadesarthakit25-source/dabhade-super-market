package com.dabhade.supermarket.repository;
import com.dabhade.supermarket.entity.HeldBill;
import org.springframework.data.jpa.repository.JpaRepository;
public interface HeldBillRepository extends JpaRepository<HeldBill,Long> {}
