package com.dabhade.supermarket.controller;

import com.dabhade.supermarket.entity.Product;
import com.dabhade.supermarket.repository.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductRepository repo;
    public ProductController(ProductRepository repo){this.repo=repo;}

    @GetMapping public List<Product> all(){return repo.findAll();}
    @GetMapping("/barcode/{barcode}") public Product barcode(@PathVariable String barcode){
        return repo.findByBarcode(barcode).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Barcode not found"));
    }
    @PostMapping public Product create(@RequestBody Product p){
        p.setId(null);
        if(p.getName()==null || p.getName().isBlank() || p.getBarcode()==null || p.getBarcode().isBlank() || p.getPrice()==null || p.getPrice().signum()<0 || p.getStock()==null || p.getStock()<0)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Enter valid product name, barcode, price and stock");
        return repo.save(p);
    }
    @PutMapping("/{id}") public Product update(@PathVariable Long id,@RequestBody Product p){
        Product old=repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        old.setName(p.getName()); old.setBarcode(p.getBarcode()); old.setPrice(p.getPrice());
        old.setGstRate(p.getGstRate()); old.setStock(p.getStock()); old.setUnit(p.getUnit());
        return repo.save(old);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){repo.deleteById(id);}
}
