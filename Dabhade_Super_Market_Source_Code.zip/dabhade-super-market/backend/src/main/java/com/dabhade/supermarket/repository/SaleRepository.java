package com.dabhade.supermarket.repository;
import com.dabhade.supermarket.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SaleRepository extends JpaRepository<Sale,Long> {}
