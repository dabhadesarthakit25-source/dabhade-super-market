import axios from 'axios'
const api = axios.create({baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080'})
export function setCredentials(username,password){
  api.defaults.headers.common.Authorization = 'Basic ' + btoa(`${username}:${password}`)
}
export default api
