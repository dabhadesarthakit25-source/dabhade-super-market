import React,{useEffect,useMemo,useState} from 'react'
import api,setCredentials from './api'

const money = n => `₹${Number(n||0).toFixed(2)}`
const blankProduct={name:'',barcode:'',price:'',gstRate:'0',stock:'0',unit:'pcs'}

export default function App(){
  const [auth,setAuth]=useState(()=>sessionStorage.getItem('dsm-auth')||'')
  const [username,setUsername]=useState('admin'),[password,setPassword]=useState('')
  const [tab,setTab]=useState('billing'),[products,setProducts]=useState([]),[sales,setSales]=useState([]),[held,setHeld]=useState([])
  const [cart,setCart]=useState([]),[barcode,setBarcode]=useState(''),[customer,setCustomer]=useState(''),[discount,setDiscount]=useState('0'),[payment,setPayment]=useState('Cash')
  const [notice,setNotice]=useState(''),[productForm,setProductForm]=useState(blankProduct),[editing,setEditing]=useState(null),[search,setSearch]=useState('')
  const [lastSale,setLastSale]=useState(null)

  const notify=m=>{setNotice(m);setTimeout(()=>setNotice(''),3500)}
  async function load(){
    try{
      const [p,s,h]=await Promise.all([api.get('/api/products'),api.get('/api/sales'),api.get('/api/held-bills')])
      setProducts(p.data);setSales(s.data);setHeld(h.data)
    }catch(e){notify(e.response?.data?.message||'Could not load data. Check backend and database.')}
  }
  useEffect(()=>{if(auth){api.defaults.headers.common.Authorization=auth;load()}},[auth])
  async function login(e){
    e.preventDefault()
    const token='Basic '+btoa(`${username}:${password}`)
    try{await api.get('/api/auth/me',{headers:{Authorization:token}});api.defaults.headers.common.Authorization=token;sessionStorage.setItem('dsm-auth',token);setAuth(token);notify('Login successful')}
    catch{notify('Invalid login or backend is not running')}
  }
  function logout(){sessionStorage.removeItem('dsm-auth');setAuth('');setCart([])}
  function addProduct(p){
    setCart(old=>{const found=old.find(x=>x.id===p.id);if(found)return old.map(x=>x.id===p.id?{...x,quantity:x.quantity+1}:x);return [...old,{...p,quantity:1}]})
    setBarcode('')
  }
  async function scan(e){
    e.preventDefault();if(!barcode.trim())return
    const p=products.find(x=>x.barcode===barcode.trim())
    if(p){addProduct(p);return}
    try{const r=await api.get('/api/products/barcode/'+encodeURIComponent(barcode.trim()));addProduct(r.data)}
    catch{notify('Product barcode not found. Add it in Products first.')}
    setBarcode('')
  }
  function changeQty(id,q){setCart(old=>old.map(x=>x.id===id?{...x,quantity:Math.max(1,Number(q)||1)}:x))}
  const subtotal=cart.reduce((s,x)=>s+Number(x.price)*x.quantity,0)
  const tax=cart.reduce((s,x)=>s+Number(x.price)*x.quantity*Number(x.gstRate||0)/100,0)
  const total=Math.max(0,subtotal+tax-Number(discount||0))
  async function checkout(){
    if(!cart.length)return notify('Add products before creating bill')
    try{
      const r=await api.post('/api/sales',{customerName:customer,paymentMethod:payment,discount:Number(discount||0),items:cart.map(x=>({productId:x.id,quantity:x.quantity}))})
      setLastSale(r.data);setCart([]);setCustomer('');setDiscount('0');await load();notify('Bill created successfully')
      setTimeout(()=>window.print(),300)
    }catch(e){notify(e.response?.data?.message||'Billing failed. Check stock and try again.')}
  }
  async function holdBill(){
    if(!cart.length)return notify('No items to hold')
    try{await api.post('/api/held-bills',{payload:JSON.stringify({cart,customer,discount,payment})});setCart([]);setCustomer('');setDiscount('0');await load();notify('Bill held')}
    catch{notify('Could not hold bill')}
  }
  async function resumeBill(id){
    try{const r=await api.get('/api/held-bills/'+id);const d=JSON.parse(r.data.payload);setCart(d.cart||[]);setCustomer(d.customer||'');setDiscount(d.discount||'0');setPayment(d.payment||'Cash');await api.delete('/api/held-bills/'+id);await load();setTab('billing')}
    catch{notify('Could not resume bill')}
  }
  async function saveProduct(e){
    e.preventDefault()
    const payload={...productForm,price:Number(productForm.price),gstRate:Number(productForm.gstRate),stock:Number(productForm.stock)}
    try{
      if(editing)await api.put('/api/products/'+editing,payload);else await api.post('/api/products',payload)
      setProductForm(blankProduct);setEditing(null);await load();notify('Product saved')
    }catch(e){notify(e.response?.data?.message||'Could not save product. Barcode may already exist.')}
  }
  function editProduct(p){setEditing(p.id);setProductForm({...p,price:String(p.price),gstRate:String(p.gstRate),stock:String(p.stock)});window.scrollTo(0,0)}
  async function deleteProduct(id){if(!confirm('Delete this product?'))return;try{await api.delete('/api/products/'+id);await load()}catch{notify('Could not delete product')}}
  async function reprint(id){try{const r=await api.get('/api/sales/'+id);setLastSale(r.data);setTimeout(()=>window.print(),100)}catch{notify('Could not load receipt')}}
  const filtered=products.filter(p=>(p.name+' '+p.barcode).toLowerCase().includes(search.toLowerCase()))
  if(!auth)return <main className="login-wrap"><form className="login-card" onSubmit={login}><div className="brand-mark">DSM</div><h1>Dabhade Super Market</h1><p>Billing & Inventory System</p><label>Username<input value={username} onChange={e=>setUsername(e.target.value)} required/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></label><button className="primary full">Login</button><small>Development login: admin / admin123 (change before real use)</small>{notice&&<div className="notice">{notice}</div>}</form></main>
  return <div className="app">
    <header className="topbar"><div><h1>Dabhade Super Market</h1><p>Billing • Inventory • Sales</p></div><div className="top-actions"><span>{new Date().toLocaleString('en-IN')}</span><button className="light" onClick={logout}>Logout</button></div></header>
    <nav className="tabs">{[['billing','Billing'],['products','Products'],['sales','Sales History'],['held','Held Bills']].map(([k,v])=><button className={tab===k?'active':''} onClick={()=>setTab(k)} key={k}>{v}</button>)}</nav>
    {notice&&<div className="toast">{notice}</div>}
    {tab==='billing'&&<div className="layout">
      <section className="panel"><div className="panel-head"><h2>Create Bill</h2><span className="pill">New sale</span></div>
        <form className="scan-row" onSubmit={scan}><input autoFocus placeholder="Scan barcode or type barcode and press Enter" value={barcode} onChange={e=>setBarcode(e.target.value)}/><button className="primary">Add item</button></form>
        <div className="quick-products"><strong>Quick add products</strong><div className="product-chips">{products.slice(0,12).map(p=><button key={p.id} onClick={()=>addProduct(p)}>{p.name} · {money(p.price)}</button>)}</div></div>
        <div className="table-scroll"><table><thead><tr><th>Item</th><th>Barcode</th><th>Price</th><th>Qty</th><th>GST</th><th>Amount</th><th></th></tr></thead><tbody>
        {cart.map(x=><tr key={x.id}><td>{x.name}</td><td>{x.barcode}</td><td>{money(x.price)}</td><td><input className="qty" type="number" min="1" value={x.quantity} onChange={e=>changeQty(x.id,e.target.value)}/></td><td>{x.gstRate}%</td><td>{money(x.price*x.quantity*(1+Number(x.gstRate||0)/100))}</td><td><button className="remove" onClick={()=>setCart(c=>c.filter(i=>i.id!==x.id))}>×</button></td></tr>)}
        {!cart.length&&<tr><td colSpan="7" className="empty">Scan a barcode or choose a product to begin.</td></tr>}
        </tbody></table></div>
        <div className="bill-fields"><label>Customer name<input value={customer} onChange={e=>setCustomer(e.target.value)} placeholder="Walk-in customer"/></label><label>Payment method<select value={payment} onChange={e=>setPayment(e.target.value)}><option>Cash</option><option>UPI</option><option>Card</option></select></label><label>Discount (₹)<input type="number" min="0" step="0.01" value={discount} onChange={e=>setDiscount(e.target.value)}/></label></div>
        <div className="bill-actions"><button className="light" onClick={holdBill}>Hold bill</button><button className="danger" onClick={()=>setCart([])}>Clear</button><button className="primary" onClick={checkout}>Create bill & Print</button></div>
      </section>
      <aside className="panel summary"><h2>Bill Summary</h2><div><span>Items</span><b>{cart.reduce((s,x)=>s+x.quantity,0)}</b></div><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>CGST</span><b>{money(tax/2)}</b></div><div><span>SGST</span><b>{money(tax/2)}</b></div><div><span>Discount</span><b>− {money(discount)}</b></div><hr/><div className="grand"><span>Total</span><b>{money(total)}</b></div><p className="muted">GST split is estimated at half of the product GST rate.</p></aside>
    </div>}
    {tab==='products'&&<div className="panel"><h2>Product Management</h2><form className="product-form" onSubmit={saveProduct}>{[['name','Product name'],['barcode','Barcode'],['price','Price ₹'],['gstRate','GST %'],['stock','Opening stock'],['unit','Unit']].map(([k,l])=><label key={k}>{l}<input required value={productForm[k]} type={['price','gstRate','stock'].includes(k)?'number':'text'} step={k==='price'||k==='gstRate'?'0.01':'1'} onChange={e=>setProductForm({...productForm,[k]:e.target.value})}/></label>)}<button className="primary">{editing?'Update product':'Add product'}</button>{editing&&<button type="button" className="light" onClick={()=>{setEditing(null);setProductForm(blankProduct)}}>Cancel</button>}</form><input className="search" placeholder="Search name or barcode" value={search} onChange={e=>setSearch(e.target.value)}/><div className="table-scroll"><table><thead><tr><th>Name</th><th>Barcode</th><th>Price</th><th>GST</th><th>Stock</th><th>Actions</th></tr></thead><tbody>{filtered.map(p=><tr key={p.id}><td>{p.name}</td><td>{p.barcode}</td><td>{money(p.price)}</td><td>{p.gstRate}%</td><td>{p.stock} {p.unit}</td><td><button className="small" onClick={()=>editProduct(p)}>Edit</button> <button className="small danger" onClick={()=>deleteProduct(p.id)}>Delete</button></td></tr>)}</tbody></table></div></div>}
    {tab==='sales'&&<div className="panel"><h2>Sales History</h2><div className="table-scroll"><table><thead><tr><th>Bill No.</th><th>Date</th><th>Customer</th><th>Payment</th><th>Total</th><th>Receipt</th></tr></thead><tbody>{sales.map(s=><tr key={s.id}><td>DSM-{s.id}</td><td>{new Date(s.createdAt).toLocaleString('en-IN')}</td><td>{s.customerName||'Walk-in'}</td><td>{s.paymentMethod}</td><td>{money(s.total)}</td><td><button className="small" onClick={()=>reprint(s.id)}>Reprint</button></td></tr>)}{!sales.length&&<tr><td colSpan="6" className="empty">No sales recorded yet.</td></tr>}</tbody></table></div></div>}
    {tab==='held'&&<div className="panel"><h2>Held Bills</h2>{held.map(h=><div className="held-row" key={h.id}><span>Held bill #{h.id} · {new Date(h.createdAt).toLocaleString('en-IN')}</span><div><button className="primary small" onClick={()=>resumeBill(h.id)}>Resume</button> <button className="danger small" onClick={async()=>{await api.delete('/api/held-bills/'+h.id);load()}}>Delete</button></div></div>)}{!held.length&&<p className="empty">No held bills.</p>}</div>}
    <footer>Dabhade Super Market · Please visit again</footer>
    <div className="print-area">{lastSale&&<Receipt sale={lastSale}/>}</div>
  </div>
}
function Receipt({sale}){
  return <div className="receipt"><h2>Dabhade Super Market</h2><p>Karjat, Maharashtra</p><p>Tax Invoice / Cash Memo</p><hr/><p>Bill: DSM-{sale.id}</p><p>{new Date(sale.createdAt).toLocaleString('en-IN')}</p><p>Customer: {sale.customerName||'Walk-in'}</p><hr/><table><thead><tr><th>Item</th><th>Qty</th><th>Rate</th><th>Amt</th></tr></thead><tbody>{sale.items?.map(i=><tr key={i.id}><td>{i.productName}</td><td>{i.quantity}</td><td>{Number(i.unitPrice).toFixed(2)}</td><td>{Number(i.lineTotal).toFixed(2)}</td></tr>)}</tbody></table><hr/><p>Subtotal: {money(sale.subtotal)}</p><p>CGST: {money(sale.cgst)}</p><p>SGST: {money(sale.sgst)}</p><p>Discount: {money(sale.discount)}</p><h3>Grand Total: {money(sale.total)}</h3><p>Payment: {sale.paymentMethod}</p><hr/><h3>Visit Again!</h3></div>
}
