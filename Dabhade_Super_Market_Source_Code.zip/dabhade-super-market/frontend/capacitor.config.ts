import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.dabhade.supermarket',
  appName: 'Dabhade Super Market',
  webDir: 'dist'
};
export default config;
