# Dabhade Super Market Billing System

A responsive React + Spring Boot + MySQL supermarket POS starter project.

## Included
- Cashier login (Spring Security HTTP Basic; credentials configured with environment variables)
- Product CRUD and barcode lookup
- Billing with quantity, discount, CGST/SGST and stock deduction
- Cash / UPI / card payment method
- Hold and resume bills
- Sales history and receipt reprint
- 80 mm thermal receipt layout
- Responsive React UI suitable for PC and Android browser
- Optional Android APK wrapper using Capacitor

> Important: This is a starter application, not certified accounting/GST software. Verify tax rules, invoice fields, HSN/SAC, invoice numbering, backups and local compliance with an accountant before production use. Use HTTPS in deployment. HTTP Basic credentials must never be sent over an unencrypted public network.

## Requirements
- Java 17+
- Maven 3.9+
- Node.js 20+
- MySQL 8+
- Android Studio (only if building APK)

## 1. Create database
Open MySQL Workbench or MySQL command line and run:

```sql
CREATE DATABASE dabhade_super_market
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Spring Boot creates the tables automatically on first run.

## 2. Start backend
Open a terminal in `backend/`.

Linux/macOS:
```bash
export DB_URL='jdbc:mysql://localhost:3306/dabhade_super_market'
export DB_USERNAME='root'
export DB_PASSWORD='YOUR_MYSQL_PASSWORD'
export APP_USERNAME='admin'
export APP_PASSWORD='ChangeThisPassword!'
mvn spring-boot:run
```

Windows PowerShell:
```powershell
$env:DB_URL="jdbc:mysql://localhost:3306/dabhade_super_market"
$env:DB_USERNAME="root"
$env:DB_PASSWORD="YOUR_MYSQL_PASSWORD"
$env:APP_USERNAME="admin"
$env:APP_PASSWORD="ChangeThisPassword!"
mvn spring-boot:run
```

Backend runs at `http://localhost:8080`.

Default development credentials if environment variables are not set:
- Username: `admin`
- Password: `admin123`

Change these before using the system with real sales.

## 3. Start React frontend
Open another terminal in `frontend/`:

```bash
npm install
npm run dev
```

Open the URL printed by Vite, normally `http://localhost:5173`.

Login using the configured backend credentials.

## 4. Android app
The same React application can be packaged as an Android app using Capacitor.

In `frontend/`:
```bash
npm install
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "Dabhade Super Market" "com.dabhade.supermarket" --web-dir=dist
```

Edit `capacitor.config.ts` and set the `server.url` only if testing against a reachable development server. For a normal APK, do not set `server.url`; build the web app into `dist` and sync it:

```bash
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

### Important Android/backend networking
An Android APK cannot use `localhost` to reach a backend running on your PC. For testing on the same Wi-Fi:
1. Find your PC's local IP address, e.g. `192.168.1.10`.
2. Ensure the backend is listening and your firewall allows port 8080.
3. Set the frontend API base URL to `http://192.168.1.10:8080`.
4. The phone and PC must be on the same network.

For real deployment, host the backend and MySQL on a secure server, use HTTPS, and set the frontend API URL to that server. Do not expose MySQL port 3306 to the internet.

## 5. Barcode scanner
Most USB/Bluetooth barcode scanners work as a keyboard: click the barcode input, scan, and the scanner types the code followed by Enter. The app also supports manual barcode entry. Camera-based scanning is not included in this starter version.

## 6. Thermal printing
The receipt page uses an 80 mm print width. In the browser print dialog choose the thermal printer, set paper width to 80 mm, margins to none/minimum, and disable headers/footers. Actual printer settings vary by model.

## 7. API summary
All endpoints require HTTP Basic authentication.

- `GET /api/auth/me`
- `GET /api/products`
- `GET /api/products/barcode/{barcode}`
- `POST /api/products`
- `PUT /api/products/{id}`
- `DELETE /api/products/{id}`
- `POST /api/sales`
- `GET /api/sales`
- `GET /api/sales/{id}`
- `POST /api/held-bills`
- `GET /api/held-bills`
- `GET /api/held-bills/{id}`
- `DELETE /api/held-bills/{id}`

## 8. Notes before real-world use
- Add a scheduled, tested database backup process.
- Add role-based permissions, audit logs and stronger session/token authentication before multi-user deployment.
- Configure correct GST rates per product and confirm inclusive/exclusive tax treatment.
- Test receipt output with your exact printer.
- Use unique product barcodes and maintain accurate opening stock.
- This starter uses simple invoice IDs and should be extended with legally compliant invoice numbering and business details.
